// src/background/chromeAsync.js
function getCookie(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.get(details, (c) => resolve(c || null));
		} catch {
			resolve(null);
		}
	});
}
function getAllCookies(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.getAll(details, (c) => resolve(c || []));
		} catch {
			resolve([]);
		}
	});
}
function createTab(props) {
	return new Promise((resolve) => {
		try {
			chrome.tabs.create(props, (t) => resolve(t || null));
		} catch {
			resolve(null);
		}
	});
}
// src/background/orgs.js
var API_SUFFIXES = [".salesforce.com", ".cloudforce.com"];
var NOT_ORGS = /* @__PURE__ */ new Set([
	"help.salesforce.com",
	"login.salesforce.com",
	"test.salesforce.com",
	"trailhead.salesforce.com"
]);
function orgIdFromSid(value) {
	const [orgId] = String(value ?? "").split("!");
	return /^00D[a-zA-Z0-9]{12}$/.test(orgId) ? orgId : null;
}
/**
* The my.salesforce.com host for any org host. Calling the lightning host would
* redirect, and the browser drops the Authorization header on a redirect.
*/
function toApiHost(host) {
	if (!host) return host;
	return host.replace(/^\./, "").replace(/\.lightning\.force\./, ".my.salesforce.").replace(/\.lightning\.([^.]+)\.force\.com$/, ".my.$1.salesforce.com").replace(/\.my\.salesforce-setup\.com$/, ".my.salesforce.com");
}
function isApiHost(host) {
	const h = String(host ?? "").replace(/^\./, "");
	return !NOT_ORGS.has(h) && API_SUFFIXES.some((s) => h.endsWith(s));
}
/**
* One entry per org from a list of sid cookies: `{ orgId, host }`. A *.my.salesforce.com
* host wins over other API hosts of the same org. Sorted by host.
*/
function groupSessions(cookies) {
	const byOrg = /* @__PURE__ */ new Map();
	for (const c of cookies || []) {
		const orgId = orgIdFromSid(c.value);
		const host = String(c.domain ?? "").replace(/^\./, "");
		if (!orgId || !isApiHost(host)) continue;
		const current = byOrg.get(orgId);
		const isMy = host.includes(".my.");
		if (!current || isMy && !current.host.includes(".my.")) byOrg.set(orgId, {
			orgId,
			host
		});
	}
	return [...byOrg.values()].sort((a, b) => a.host.localeCompare(b.host));
}
// src/background/oauth.js
var TOKEN = (orgId) => `dci_oauth_${orgId}`;
var CLIENT = (orgId) => `dci_oauthClient_${orgId}`;
function base64url(bytes) {
	let s = "";
	for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b);
	return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
async function pkcePair(random = (n) => crypto.getRandomValues(new Uint8Array(n))) {
	const verifier = base64url(random(48));
	return {
		verifier,
		challenge: base64url(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)))
	};
}
function authorizeUrl({ host, clientId, redirectUri, challenge, state }) {
	return `https://${host}/services/oauth2/authorize?${new URLSearchParams({
		response_type: "code",
		client_id: clientId,
		redirect_uri: redirectUri,
		code_challenge: challenge,
		code_challenge_method: "S256",
		state
	})}`;
}
/** The code from the redirect, after checking the state; throws Salesforce's error otherwise. */
function codeFromRedirect(url, state) {
	const u = new URL(url);
	const p = new URLSearchParams(u.search || u.hash.slice(1));
	if (p.get("error")) throw new Error(`${p.get("error")}: ${p.get("error_description") || ""}`.trim());
	if (p.get("state") !== state) throw new Error("The login answer did not match this request; try again.");
	const code = p.get("code");
	if (!code) throw new Error("Salesforce did not return an authorization code.");
	return code;
}
/** The 15-character org ID in a token response's identity URL (…/id/<orgId>/<userId>). */
function orgIdOfToken(token) {
	const m = String(token?.id || "").match(/\/id\/(00D[a-zA-Z0-9]{12,15})\//);
	return m ? m[1].slice(0, 15) : null;
}
function sessionGet(key) {
	return new Promise((resolve) => {
		try {
			chrome.storage.session.get(key, (r) => resolve(r?.[key] || null));
		} catch {
			resolve(null);
		}
	});
}
function sessionSet(items) {
	return new Promise((resolve) => {
		try {
			chrome.storage.session.set(items, () => resolve());
		} catch {
			resolve();
		}
	});
}
function sessionRemove(key) {
	return new Promise((resolve) => {
		try {
			chrome.storage.session.remove(key, () => resolve());
		} catch {
			resolve();
		}
	});
}
function localGet(key) {
	return new Promise((resolve) => {
		try {
			chrome.storage.local.get(key, (r) => resolve(r?.[key] || ""));
		} catch {
			resolve("");
		}
	});
}
function localSet(items) {
	return new Promise((resolve) => {
		try {
			chrome.storage.local.set(items, () => resolve());
		} catch {
			resolve();
		}
	});
}
function redirectUri() {
	try {
		return chrome.identity.getRedirectURL();
	} catch {
		return "";
	}
}
async function oauthStatus(orgId) {
	const t = await sessionGet(TOKEN(orgId));
	return {
		active: !!t,
		since: t?.at || null,
		clientId: await localGet(CLIENT(orgId)),
		redirectUri: redirectUri()
	};
}
/** `{ host, sid }` from a stored OAuth token, or null. */
async function oauthSession(orgId) {
	const t = await sessionGet(TOKEN(orgId));
	return t ? {
		host: t.host,
		sid: t.accessToken,
		oauth: true
	} : null;
}
async function forgetToken(orgId) {
	await sessionRemove(TOKEN(orgId));
}
async function oauthLogin({ orgId, host, clientId }, deps = {}) {
	const launch = deps.launchWebAuthFlow || ((opts) => chrome.identity.launchWebAuthFlow(opts));
	const fetchFn = deps.fetch || fetch;
	const redirect = deps.redirectUri || redirectUri();
	if (!clientId?.trim()) throw new Error("Enter the client ID of your External Client App first.");
	await localSet({ [CLIENT(orgId)]: clientId.trim() });
	const { verifier, challenge } = await pkcePair();
	const state = base64url(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16)));
	const answer = await launch({
		url: authorizeUrl({
			host,
			clientId: clientId.trim(),
			redirectUri: redirect,
			challenge,
			state
		}),
		interactive: true
	});
	if (!answer) throw new Error("The login window was closed.");
	const code = codeFromRedirect(answer, state);
	const res = await fetchFn(`https://${host}/services/oauth2/token`, {
		method: "POST",
		headers: {
			"Content-Type": "application/x-www-form-urlencoded",
			Accept: "application/json"
		},
		body: new URLSearchParams({
			grant_type: "authorization_code",
			code,
			client_id: clientId.trim(),
			redirect_uri: redirect,
			code_verifier: verifier
		}).toString(),
		credentials: "omit"
	});
	const token = await res.json().catch(() => ({}));
	if (!res.ok || !token.access_token) throw new Error(token.error_description || token.error || `Token request failed (HTTP ${res.status})`);
	const tokenOrg = orgIdOfToken(token);
	if (tokenOrg && tokenOrg !== orgId) throw new Error(`You logged in to a different org (${tokenOrg}). Log in to ${host}.`);
	const instance = token.instance_url ? new URL(token.instance_url).host : host;
	await sessionSet({ [TOKEN(orgId)]: {
		accessToken: token.access_token,
		host: instance,
		at: (/* @__PURE__ */ new Date()).toISOString(),
		scope: token.scope || ""
	} });
	return {
		ok: true,
		scope: token.scope || ""
	};
}
// src/background/sessions.js
var DOMAINS = ["salesforce.com", "cloudforce.com"];
async function allSidCookies() {
	return (await Promise.all(DOMAINS.map((domain) => getAllCookies({
		name: "sid",
		domain,
		secure: true
	})))).flat();
}
/** `[{ orgId, host }]` for every org the browser has an API session for. */
async function listOrgs() {
	return groupSessions(await allSidCookies());
}
/** The org of a Salesforce tab, or null. */
async function orgForUrl(url) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return null;
	}
	const orgId = orgIdFromSid((await getCookie({
		url: parsed.origin,
		name: "sid"
	}))?.value);
	if (!orgId) return null;
	return (await listOrgs()).find((o) => o.orgId === orgId) || {
		orgId,
		host: toApiHost(parsed.hostname)
	};
}
/**
* `{ host, sid }` for an org, or null when there is no session (logged out). An OAuth token
* from Settings, Log in with OAuth, comes first (`oauth: true`).
*/
async function sessionFor(orgId) {
	const oauth = await oauthSession(orgId);
	if (oauth) return oauth;
	const cookies = await allSidCookies();
	const org = groupSessions(cookies).find((o) => o.orgId === orgId);
	if (!org) return null;
	const cookie = cookies.find((c) => c.domain.replace(/^\./, "") === org.host && orgIdFromSid(c.value) === orgId);
	return cookie ? {
		host: org.host,
		sid: cookie.value
	} : null;
}
// src/background/guard.js
var READ_POSTS = [
	/^\/services\/data\/v\d+\.\d+\/ssot\/query-sql\/?$/,
	/^\/services\/data\/v\d+\.\d+\/ssot\/queryv2\/?$/,
	/^\/services\/data\/v\d+\.\d+\/ssot\/query\/?$/
];
function checkRequest(method, path) {
	const m = String(method || "GET").toUpperCase();
	const p = String(path ?? "");
	if (!p.startsWith("/services/")) return "Only Salesforce API paths (/services/...) are allowed.";
	if (p.includes("..") || /[\s\\]/.test(p.split("?")[0])) return "That path is not allowed.";
	if (m === "GET" || m === "HEAD") return null;
	const bare = p.split("?")[0];
	if (m === "POST" && READ_POSTS.some((re) => re.test(bare))) return null;
	return `Data Cloud Inspector is read only: ${m} ${bare} is not allowed.`;
}
// src/background/fetchProxy.js
var CLIENT_NAME = "DataCloudInspector";
/** Salesforce error bodies are `[{ errorCode, message }]`; anything else is shortened. */
function errorMessage(status, data, text) {
	if (Array.isArray(data) && data.length && data[0]?.message) return data.map((e) => e.errorCode ? `${e.errorCode}: ${e.message}` : e.message).join("\n");
	if (data && typeof data === "object" && (data.message || data.error)) return String(data.message || data.error_description || data.error);
	const t = String(text ?? "");
	return t.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || t.substring(0, 300) || `HTTP ${status}`;
}
/**
* `{ ok, status, ms, data }` or `{ ok: false, status, ms, error, data }`.
* status 0 means the request never got a response.
*/
async function sfFetch({ orgId, path, method = "GET", body }, deps = {}) {
	const fetchFn = deps.fetch || fetch;
	const getSession = deps.sessionFor || sessionFor;
	const refused = checkRequest(method, path);
	if (refused) return {
		ok: false,
		status: 0,
		ms: 0,
		error: refused,
		code: "READ_ONLY"
	};
	const session = await getSession(orgId);
	if (!session) return {
		ok: false,
		status: 0,
		ms: 0,
		error: "No Salesforce session for this org. Log in to it in this browser, then try again.",
		code: "NO_SESSION"
	};
	const headers = {
		Authorization: `Bearer ${session.sid}`,
		Accept: "application/json",
		"Sforce-Call-Options": `client=${CLIENT_NAME}`
	};
	const opts = {
		method: method.toUpperCase(),
		headers,
		credentials: "omit",
		cache: "no-store"
	};
	if (body != null) {
		headers["Content-Type"] = "application/json";
		opts.body = typeof body === "string" ? body : JSON.stringify(body);
	}
	const started = Date.now();
	let res;
	try {
		res = await fetchFn(`https://${session.host}${path}`, opts);
	} catch (err) {
		return {
			ok: false,
			status: 0,
			ms: Date.now() - started,
			error: `Network error: ${err.message}`
		};
	}
	const text = await res.text();
	const ms = Date.now() - started;
	let data = null;
	try {
		data = text ? JSON.parse(text) : null;
	} catch {
		data = null;
	}
	if (res.ok) return {
		ok: true,
		status: res.status,
		ms,
		data: data ?? text
	};
	if (res.status === 401 && session.oauth) {
		await (deps.forgetToken || forgetToken)(orgId);
		return {
			ok: false,
			status: 401,
			ms,
			error: "The OAuth login has expired. Log in with OAuth again in Settings.",
			data
		};
	}
	return {
		ok: false,
		status: res.status,
		ms,
		error: errorMessage(res.status, data, text),
		data
	};
}
// src/background/index.js
var APP_PAGE = "app.html";
chrome.action?.onClicked?.addListener(async (tab) => {
	const org = tab?.url ? await orgForUrl(tab.url) : null;
	createTab({
		url: chrome.runtime.getURL(APP_PAGE) + (org ? `?org=${org.orgId}` : ""),
		index: tab ? tab.index + 1 : void 0,
		openerTabId: tab?.id
	});
});
var handlers = {
	LIST_ORGS: async () => ({ orgs: await listOrgs() }),
	ORG_FOR_URL: async ({ url }) => ({ org: await orgForUrl(url) }),
	SF_FETCH: (msg) => sfFetch(msg),
	OAUTH_STATUS: ({ orgId }) => oauthStatus(orgId),
	OAUTH_LOGIN: async ({ orgId, clientId }) => {
		const org = (await listOrgs()).find((o) => o.orgId === orgId);
		if (!org) return {
			ok: false,
			error: "That org is not logged in in this browser."
		};
		try {
			return await oauthLogin({
				orgId,
				host: org.host,
				clientId
			});
		} catch (err) {
			return {
				ok: false,
				error: err.message
			};
		}
	},
	OAUTH_LOGOUT: async ({ orgId }) => {
		await forgetToken(orgId);
		return { ok: true };
	}
};
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
	if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL(""))) return false;
	const handler = handlers[msg?.type];
	if (!handler) return false;
	handler(msg).then(sendResponse, (err) => sendResponse({
		ok: false,
		status: 0,
		error: err.message
	}));
	return true;
});
